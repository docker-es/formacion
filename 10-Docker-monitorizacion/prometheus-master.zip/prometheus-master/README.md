# prometheus

This repository hosts sample code used in the Upnxtblog [article]( http://www.upnxtblog.com/index.php/2019/02/10/monitoring-docker-containers-using-prometheus-cadvisor-grafana).Sample starter kit on how to monitor Docker containers using Prometheus + cAdvisor + Grafana.
